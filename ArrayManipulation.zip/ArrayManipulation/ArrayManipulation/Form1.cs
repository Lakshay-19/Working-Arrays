﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArrayManipulation
{
    public partial class Form1 : Form
    {
        //global variables
        int[] Data = { 1, 5, 8, 3, 2, 9, 15, 7 };

        public Form1()
        {
            InitializeComponent();
        }

        private void btnList_Click(object sender, EventArgs e)
        {
            String Output = String.Empty;

            //output the values in Data in a list format

            for (int i=0; i < Data.Length; i++)
            {
                Output = Output + Data[i] + "\n";
            }
            lblOutput.Text = Output;
        }

        private void btnSum_Click(object sender, EventArgs e)
        {
            //output the sum of values in Data

            double Sum = 0;

            for (int i = 0; i < Data.Length; i++)
            {
                Sum += Data[i];

            }

            lblOutput.Text = "Sum of data is " + Sum;


        }

        private void btnAverage_Click(object sender, EventArgs e)
        {
            //output the average of the values in Data

            double Sum = 0;

            for (int i=0; i < Data.Length; i++)
            {
                Sum += Data[i];
            }

            double Average = Sum / Data.Length;
            lblOutput.Text = "Average is " + Average;

        }


        private void btnReverse_Click(object sender, EventArgs e)
        {
            //output Data in reverse order

            String Output = String.Empty;

            //output the values in Data in a list format

            for (int i = Data.Length - 1; i >= 0; i--)
            {
                Output = Output + Data[i] + "\n";
            }
            lblOutput.Text = Output;

        }

        private void btnCopy_Click(object sender, EventArgs e)
        {

            //copy the values from Data into the an array named Copy
            int [] Copy = new int[Data.Length];

            for (int i = 0; i < Data.Length; i++)
            {
                Copy[i] = Data[i];
             }

            string Output = string.Empty;

            for (int i = 0; i < Copy.Length; i++)
            {
                Output += Copy[i] + "\n";
            }



        }
    }
}
